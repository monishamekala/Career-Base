<?php

session_start();

$connection = mysqli_connect("localhost", "root", "", "careerbase");

$query = "SELECT * FROM main";
$query_run = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		.fnt{
			font-size: 20px; 
			color: #45526c;
		}
		.card-body {
            background-image: linear-gradient(to left, #eeebdd, #eeebdd); 
        }
        .cont{
        	margin-top: 50px;
        	margin-left: 100px;
        }
        .Last{
        	position: fixed;
            bottom: 0;
            right: 0;
        }
        .card-body{
        	width: 30rem;
        }
        .fntt{
			font-size: 30px; 
			color: #f05945;
		}
	</style>
	<title>Career base-Find jobs</title>
	<link rel = "icon" href = "./images/logo.jpg" type = "image/x-icon">
</head>
<body>
	<nav class="navbar navbar-light bg-light">
	  <a class="navbar-brand" href="index.php">
	    <img src="./images/logo.jpg" width="50" height="50" class="d-inline-block align-top" alt="">
	    <font class="fntt"><b>CodeKaroYaaro</b></font>
	  </a>
	</nav>

	<?php 
		if (mysqli_num_rows($query_run) > 0) {
        	while ($result = mysqli_fetch_assoc($query_run)) {?>
        		<div class="cont">
	        		<div class="card" style="width: 18rem;">
					  <div class="card-body">
					    <h2 class="card-title">
					    	<font style="color: #45526c">
					    	<b><?php echo $result['title'];?></b>
					    	</font>
					    </h2>
					    <font class="fnt">
						    <p>
						    	<b><?php echo "Experience Required:";?></b>
						    	<?php echo $result['exp_rqrd'];?>
						    </p>
						    <p>
						    	<b><?php echo "Location:";?></b>
						    	<?php echo $result["location"];?>
						    </p>
						    <p>
						    	<b><?php echo "Skills Required:";?></b>
						    	<?php echo $result['skill_rqrd'];?>
						    </p>
						    <p style="white-space: pre-line">
						    	<b>Responsible for:</b>
						    	<?php echo $result['respns'];?>
						    </p>
						</font>
					  </div>
					</div>
				</div>
			<?php 
			}
		}
		else {
			?>
			<h2 class="card-title cont">
		    	<font style="color: #45526c">
		    	<b><?php echo "No Jobs found...";?></b>
		    	</font>
		    </h2>
		<?php
		} ?>
	<div class = "Last">
	<a href="./find.php" type="button" class="btn btn-outline-secondary btn-lg">
		Go to top<span>&#8593;</span>
	</a>
	</div>
</body>
</html>