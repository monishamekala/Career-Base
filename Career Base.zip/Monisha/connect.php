<?php
$title = filter_input(INPUT_POST, 'title');
$experience = filter_input(INPUT_POST, 'exp');
$location = filter_input(INPUT_POST, 'loc');
$skill = filter_input(INPUT_POST, 'sklRqrd');
$responsble = filter_input(INPUT_POST, 'resp');

if (!empty($title)) {
    if (!empty($experience)) {
        if (!empty($location)) {
            if (!empty($skill)) {
                $host = "localhost";
                $dbusername = "root";
                $dbpassword = "";
                $dbname = "careerbase";
                // Create connection
                $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);
                if (mysqli_connect_error()) {
                    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
                } else {
                    $sql = "INSERT INTO main (title, exp_rqrd, location, skill_rqrd, respns) values ('$title','$experience','$location','$skill','$responsble')";
                    if ($conn->query($sql)) {
                        header("location: fillform.php");
                    } else {
                        echo "Error: " . $sql . "" . $conn->error;
                    }
                    $conn->close();
                }
            } else {
                header("location: fillform.php");
                die();
            }
        } else {
            header("location: fillform.php");
            die();
        }
    } else {
        header("location: fillform.php");
        die();
    }
} else {
    header("location: fillform.php");
    die();
}
