<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "careerbase");
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		.algn{
			padding-top: 50px;
			padding-bottom: 50px;
		}
		.fnt{
			font-size: 30px; 
			color: #f05945;
		}
		.fnt1{
			font-size: 23px;
			font-family: Arial, Helvetica, sans-serif; 
			text-shadow: 2px 2px 2px #ababab;
		}
		.bg-body {
			border-radius: 30px;
            background-image: linear-gradient(to left, #eeebdd, #eeebdd);
        }
        .container{
        	margin-top: 80px;
        }
        .text-line {
		    background-color: transparent;
		    color: #000000;
		    outline: none;
		    outline-style: none;
		    border-top: none;
		    border-left: none;
		    border-right: none;
		    border-bottom: solid #000000 1px;
		    padding: 3px 10px;
		    margin-left: 20px;
		}
		.b1{
			margin-left: 130px;
		}
		.fntt{
			font-size: 30px; 
			color: #f05945;
		}
		.Last{
        	position: fixed;
            bottom: 0;
            right: 20px;
        }
	</style>
	<title>Career base-Recruit</title>
	<link rel = "icon" href = "./images/logo.jpg" type = "image/x-icon">
</head>
<body>
	<nav class="navbar navbar-light bg-light">
	  <a class="navbar-brand" href="index.php">
	    <img src="./images/logo.jpg" width="50" height="50" class="d-inline-block align-top" alt="">
	    <font class="fntt"><b>CodeKaroYaaro</b></font>
	  </a>
	</nav>

	<div class="container algn bg-body">
		<form action="connect.php" method="post">
                <div class="form-group">
                	<label><font class="fnt1"><b>Job Title *</b></font>
                    	<input type="text" class="text-line"name="title">
                    </label>
                </div>

                <div class="form-group">
                	<label><font class="fnt1"> <b>Experience Required *</b></font>
                    	<input type="text" class="text-line" name="exp">
                    </label>
                </div>

                <div class="form-group">
                	<label><font class="fnt1"> <b>Location *</b></font>
                    	<input type="text" class="text-line"name="loc">
                	</label>
                </div>

                <div class="form-group">
                	<label><font class="fnt1"> <b>Skills Required *</b></font>
                    	<input type="text" class="text-line" name="sklRqrd">
                	</label>
                </div>

                <div class="form-group">
                	<label> <font class="fnt1"><b>Resposible for</b></font>
                    	<textarea rows="5" cols="70" name="resp" id="Description"></textarea>
                    </label>
                </div>
                <div style="margin-left: 15px;">
                <input type="submit" value="Submit" class="btn btn-outline-secondary btn-lg">
                </div>
        </form>
    </div>
    <div class = "Last">
	<a href="./index.php" type="button" class="btn btn-outline-secondary btn-lg">Back</a>
	</div>
</body>
</html>