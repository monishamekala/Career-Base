<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "careerbase");
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		.algn{
			padding-top: 100px;
		}
		.fnt{
			font-size: 30px; 
			color: #f05945;
		}
	</style>
	<title>Career base</title>
	<link rel = "icon" href = "./images/logo.jpg" type = "image/x-icon">
</head>
<body>
	<nav class="navbar navbar-light bg-light">
	  <a class="navbar-brand" href="#">
	    <img src="./images/logo.jpg" width="50" height="50" class="d-inline-block align-top" alt="">
	    <font class="fnt"><b>CodeKaroYaaro</b></font>
	  </a>
	</nav>

	<div class="container algn">
	<a href="./find.php" type="button" class="btn btn-outline-danger btn-lg">Find Jobs</a>
	<p></p>
	<a href="./fillform.php" type="button" class="btn btn-outline-danger btn-lg">Recruit</a>
	</div>

</body>
</html>